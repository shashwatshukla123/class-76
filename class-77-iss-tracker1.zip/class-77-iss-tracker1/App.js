import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './screens/HomeScreen';
import IssLocation from './screens/IssLocation';
import Meteors from './screens/Meteors';
import Updates from './screens/Updates';

const Stack = createStackNavigator();

export default class App extends React.Component{
  render(){
    return(
      <NavigationContainer>
      <Stack.Navigator initialRouteName="Home"
      screensOptions={{
        headerShown:false
      }}>

      <Stack.Screen name="Home" component={HomeScreen}/>
      <Stack.Screen name="Iss-Location" component={IssLocation}/>
      <Stack.Screen name="Meteor" component={Meteors}/>
      <Stack.Screen name="Updates" component={Updates}/>

      </Stack.Navigator>
    </NavigationContainer>
    )
  }
}

